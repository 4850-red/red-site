export interface MotorReq {
    id: number
    pos: number
    torq: number
}