export interface Motion {
  id: number
  name: string
  button: string
}
