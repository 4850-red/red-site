# api-ts
API Server for raspberry pi in typescript
