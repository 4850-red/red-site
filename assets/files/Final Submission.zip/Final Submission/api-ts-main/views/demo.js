$('.head').on('input', function() {
    console.log(this.val)
})