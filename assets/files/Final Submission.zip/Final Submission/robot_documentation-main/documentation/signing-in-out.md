---
layout: default
nav_order: 1
parent: Documentation
---

# Signing in/out

Only students working on the robots are allowed in the room. No less than two students can be in the room together. All students must sign in when they enter the room.

Fill out the sign in sheet to the best of your ability. Time in and out should be as accurate as possible, so the first and last things you do in the room should be filling those out. Give a brief statement on work performed and an estimate on time spent in room.
